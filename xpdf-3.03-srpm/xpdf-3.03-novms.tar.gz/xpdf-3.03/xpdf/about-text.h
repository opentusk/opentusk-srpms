//========================================================================
//
// about-text.h
//
// Copyright 2002-2007 Glyph & Cog, LLC
//
//========================================================================

static const char *aboutWinText[] = {
  "http://www.foolabs.com/xpdf/",
  "derekn@foolabs.com",
  " ",
  "Licensed under the GNU General Public License (GPL) v2 or v3.",
  "See the 'README' file for details.",
  " ",
  "Supports PDF version " supportedPDFVersionStr ".",
  " ",
  "The PDF data structures, operators, and specification",
  "are copyright 1985-2006 Adobe Systems Inc.",
  " ",
  "For more information (including key and mouse bindings)",
  "please read the xpdf(1) man page.",
  NULL
};
