package LoadTest;

use Does::Not::Exist;

sub new {}


1;
